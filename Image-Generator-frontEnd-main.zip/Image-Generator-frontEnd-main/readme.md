# React Setup

make 3 basic files
--> index.html
--> styles.css
--> app.js

initialize npm repo:
--> npm init -y

install dependencies:
--> npm i react
--> npm i react-dom
--> npm i parcel

run the app:
--> npx parcel index.html