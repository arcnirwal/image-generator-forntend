import { createContext } from 'react';

const PointsContext = createContext();

export default PointsContext;